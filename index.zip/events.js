import * as Utils from './utils.js';
import * as Data from './data.js';
import * as UI from './ui.js';
import * as Stats from './stats.js';
import * as DateCtrl from './date_controls.js';
import { parseSmsText } from './sms_parser.js';

export function setupEventListeners(updateAllDisplays) {
    const getEl = (id) => document.getElementById(id);

    // [중요] 필드셋 아코디언 (기록일시, 종류, 금액정보)
    document.querySelectorAll('.section-toggle-label').forEach(label => {
        label.onclick = function() {
            const targetId = this.getAttribute('data-target');
            const targetBody = document.getElementById(targetId);
            if (targetBody) {
                const isHidden = targetBody.classList.contains('hidden');
                if (isHidden) {
                    targetBody.classList.remove('hidden');
                    this.classList.add('active');
                } else {
                    targetBody.classList.add('hidden');
                    this.classList.remove('active');
                }
            }
        };
    });

    // SMS 분석
    getEl('btn-parse-sms')?.addEventListener('click', parseSmsText);

    // 주소 복사 (오늘 테이블 등)
    document.body.addEventListener('click', (e) => {
        const addrTarget = e.target.closest('.location-clickable');
        if (addrTarget) {
            const center = addrTarget.getAttribute('data-center');
            const loc = Data.MEM_LOCATIONS[center];
            Utils.copyTextToClipboard(loc?.address || center, '복사됨');
        }
    });

    // 상/하차지 입력 시 자동 완성 로직
    const handleLocationInput = () => {
        const from = getEl('from-center').value.trim();
        const to = getEl('to-center').value.trim();
        const type = getEl('type').value;
        if((type === '화물운송' || type === '대기') && from && to) {
            const key = `${from}-${to}`;
            if(getEl('income')) getEl('income').value = Data.MEM_FARES[key] ? (Data.MEM_FARES[key]/10000).toFixed(2) : '';
            if(getEl('manual-distance')) getEl('manual-distance').value = Data.MEM_DISTANCES[key] || '';
            if(getEl('cost')) getEl('cost').value = Data.MEM_COSTS[key] ? (Data.MEM_COSTS[key]/10000).toFixed(2) : '';
        }
        UI.updateAddressDisplay();
    };
    getEl('from-center')?.addEventListener('input', handleLocationInput);
    getEl('to-center')?.addEventListener('input', handleLocationInput);

    // 버튼 동작
    getEl('btn-register-trip')?.onclick = () => {
        const formData = UI.getFormDataWithoutTime();
        Data.addRecord({ id: Date.now(), date: getEl('date').value, time: getEl('time').value, ...formData });
        Utils.showToast('등록됨'); UI.resetForm(); updateAllDisplays();
    };

    getEl('btn-start-trip')?.onclick = () => {
        const formData = UI.getFormDataWithoutTime();
        Data.addRecord({ id: Date.now(), date: Utils.getTodayString(), time: Utils.getCurrentTimeString(), ...formData });
        Utils.showToast('시작됨'); UI.resetForm(); updateAllDisplays();
    };

    getEl('btn-end-trip')?.onclick = () => {
        Data.addRecord({ id: Date.now(), date: Utils.getTodayString(), time: Utils.getCurrentTimeString(), type: '운행종료', distance: 0, cost: 0, income: 0 });
        Utils.showToast('종료됨'); UI.resetForm(); updateAllDisplays();
    };

    getEl('btn-save-general')?.onclick = () => {
        const formData = UI.getFormDataWithoutTime();
        Data.addRecord({ id: Date.now(), date: getEl('date').value, time: getEl('time').value, ...formData });
        Utils.showToast('저장됨'); UI.resetForm(); updateAllDisplays();
    };

    // 설정 페이지 전환
    getEl('go-to-settings-btn')?.onclick = () => {
        getEl('main-page').classList.add('hidden');
        getEl('settings-page').classList.remove('hidden');
        getEl('go-to-settings-btn').classList.add('hidden');
        getEl('back-to-main-btn').classList.remove('hidden');
        Stats.displayCumulativeData();
        Stats.displayCurrentMonthData();
    };

    getEl('back-to-main-btn')?.onclick = () => {
        getEl('main-page').classList.remove('hidden');
        getEl('settings-page').classList.add('hidden');
        getEl('go-to-settings-btn').classList.remove('hidden');
        getEl('back-to-main-btn').classList.add('hidden');
        updateAllDisplays();
    };

    // 설정 내 아코디언
    document.querySelectorAll('.collapsible-header').forEach(header => {
        header.onclick = () => {
            header.classList.toggle('active');
            header.nextElementSibling.classList.toggle('hidden');
        };
    });

    // 날짜 선택기
    getEl('today-date-picker')?.onchange = () => updateAllDisplays();
    getEl('prev-day-btn')?.onclick = () => DateCtrl.moveDate(-1, updateAllDisplays);
    getEl('next-day-btn')?.onclick = () => DateCtrl.moveDate(1, updateAllDisplays);

    // 탭 전환
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.onclick = () => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.view-content').forEach(v => v.classList.remove('active'));
            btn.classList.add('active');
            getEl(btn.dataset.view + '-view').classList.add('active');
            updateAllDisplays();
        };
    });

    getEl('type')?.addEventListener('change', UI.toggleUI);
}